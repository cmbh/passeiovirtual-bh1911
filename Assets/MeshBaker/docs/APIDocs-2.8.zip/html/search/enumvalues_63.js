var searchData=
[
  ['copy_5fuv2_5funchanged',['copy_UV2_unchanged',['../namespace_digital_opus_1_1_m_b_1_1_core.html#a7c6398a07657fe2d755d25429858086cad6467bb91f2b5b37697f13261bbd3dd6',1,'DigitalOpus::MB::Core']]]
];
