var searchData=
[
  ['prefabonly',['prefabOnly',['../_m_b2___mesh_baker_root_8cs.html#a3d88ce5ea51c6313e8775d53e3f11607ad69e089f38b1dc0ca132a4c696d268cb',1,'MB2_MeshBakerRoot.cs']]],
  ['preserve_5fcurrent_5flightmapping',['preserve_current_lightmapping',['../namespace_digital_opus_1_1_m_b_1_1_core.html#a7c6398a07657fe2d755d25429858086ca493573de4d5e57f230f3061abdc012f2',1,'DigitalOpus::MB::Core']]]
];
