var searchData=
[
  ['fixoutofboundsuvs',['fixOutOfBoundsUVs',['../class_m_b2___texture_baker.html#a5ca5b36da566f5971e1abb75a423bcd9',1,'MB2_TextureBaker.fixOutOfBoundsUVs()'],['../class_m_b2___texture_bake_results.html#a2691265940fa5099d4d559875ba02a72',1,'MB2_TextureBakeResults.fixOutOfBoundsUVs()']]]
];
